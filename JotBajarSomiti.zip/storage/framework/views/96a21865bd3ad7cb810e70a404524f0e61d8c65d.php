<?php $__env->startSection('hirizontal_nav_sonchoy_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>



<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links" style="font-size: 17px;">

		<div class="list-group">

		  <a href="<?php echo e(route('user.sonchoy_biboron')); ?>" class="list-group-item active">সঞ্চয় বিবরন </a>

		  <a href="<?php echo e(route('user.sonchoy_uttolon')); ?>" class="list-group-item">সঞ্চয় উত্তোলন </a>
		  
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

	<div class="table-responsive" style="margin-top: 20px;">
	  <table class="table table-hover table-striped">
	    
	  	<thead>
	  	      <tr>
	  	        
	  	        <th style="text-align: center; font-size: 22px;">বিবরনের ধরন </th>
	  	        <th style="text-align: center; font-size: 22px;">মাসিক সঞ্চয় </th>
	  	        <th style="text-align: center; font-size: 22px;">জরিমানা</th>
	  	        <th style="text-align: center; font-size: 22px;">মোট প্রদান</th>
	  	        <th style="text-align: center; font-size: 22px;">বর্তমানে সঞ্চয়</th>
	  	        <th style="text-align: center; font-size: 22px;">তারিখ</th>
	  	      </tr>
	  	</thead>
	  	    <tbody style="text-align: center; font-size: 22px;">

	  	    	<?php $__currentLoopData = $sonchoy_instance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_sonchoy_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	    		

		  	      <tr>
		  	        <td>
		  	        	
		  	        	<?php if($single_sonchoy_info->info_type == "sonchoy_masik_joma"): ?>
		  	        		
		  	        		<?php echo e("মাসিক জমা "); ?>


		  	        	<?php elseif($single_sonchoy_info->info_type == "sonchoy_munafa"): ?>

		  	        		<?php echo e("সঞ্চয়ের মুনাফা"); ?>



		  	        	<?php elseif($single_sonchoy_info->info_type == "sheyar_munafa"): ?>

		  	        		<?php echo e("শেয়ারের মুনাফা "); ?>


		  	        	<?php endif; ?>

		  	        </td>
		  	        <td><?php echo e($single_sonchoy_info->money_amount); ?></td>
		  	        <td><?php echo e($single_sonchoy_info->jorimana_amount); ?></td>
		  	        <td><?php echo e($single_sonchoy_info->total_amount); ?></td>
		  	        <td><?php echo e($single_sonchoy_info->current_month_sonchoy); ?></td>
		  	        <td><?php echo e($single_sonchoy_info->updated_at->formatLocalized('%A %d %B %Y')); ?></td>
		  	      </tr>
	  	    		
	  	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	      
	  	    </tbody>

	  </table>
	</div>

	<div class="pull-right" style="font-size: 20px;">

		<?php echo e($sonchoy_instance->links()); ?>

		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>