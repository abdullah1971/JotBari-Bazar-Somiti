<?php $__env->startSection('hirizontal_nav_report_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>


<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links">

		<div class="list-group">

      <a href="<?php echo e(route('company.daily_report')); ?>" class="list-group-item">ডেইলি রিপোর্ট</a>
      <a href="<?php echo e(route('company.monthly_report')); ?>" class="list-group-item">মাসিক রিপোর্ট</a>
      <a href="<?php echo e(route('company.closing_report')); ?>" class="list-group-item active">ক্লোজিং রিপোর্ট </a>
		  
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Form Design <small>different form elements</small></h2>
            
            <div class="clearfix"></div>
          </div>
        <div>
        <br />

        <form id="" class="form-horizontal form-label-left" method="post" action="<?php echo e(route('company.closing_report_info')); ?>">

        	<?php echo e(csrf_field()); ?>


              <div class="row">
                
                <div class="col-sm-5 col-md-5 col-xl-6">
                  
                  <div id="month_for_monthly_report" class="form-group">
                    <label for="month_for_monthly_report_input" class="control-label col-md-3 col-sm-3 col-xs-12">
                      ভাগ  
                    </label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                      

                      <select id='half' name="half"  class="form-control col-md-7 col-xs-12">
                          <option value=''>--Select Month--</option>
                          <option style="font-size: 20px;" value='1'>Janaury</option>
                          <option style="font-size: 20px;" value='2'>Jully</option>
                          
                      </select> 

                    </div>
                  </div>

                </div>

                <div class="col-sm-5 col-md-5 col-xl-6">
                  
                  <div id="year_for_monthly_report" class="form-group">
                    <label for="year_for_monthly_report_input" class="control-label col-md-3 col-sm-3 col-xs-12">
                      বছর 
                    </label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                      

                      <?php
                        
                        $start_year = 1980;

                        $end_year = Carbon\Carbon::now()->year;

                      ?>

                      <select id='year' name="year"  class="form-control col-md-7 col-xs-12">
                          <option value=''>--Select Year--</option>
                          <?php for($i = $end_year; $i >= $start_year; $i--): ?>
                            
                            <option style="font-size: 20px;" value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            
                          <?php endfor; ?>
                          
                          </select> 

                    </div>
                  </div>

                </div>




                <div class="col-sm-2 col-md-2 col-xl-2">
                  

                  <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12">
                      
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      
                      <button type="submit" class="btn btn-success pull-right">Submit</button>

                  

                    </div>
                  </div>

                </div>

              </div>

              

              


              


            

              --}}
        </form>
      </div>
    </div>




    <!-- masik report info -->


      <?php if($closing_info_instance != null): ?>
        

          <div class="row" style="position: ;background-color: #27ae60; color: white;font-size: 21px;">
            
            <div class="col-sm-1 col-md-1 col-xl-1">
              তারিখ
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              সঞ্চয় আদায়
            </div>

            <div class="col-sm-5 col-md-5 col-xl-5">

              <div class="row">

                <div class="col-sm-2 col-md-2 col-xl-2">
                  মুনাফা আদায়
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  শেয়ার আদায়
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  রিজার্ভ আদায়
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  ভবন থেকে আদায়
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  ঋণ আদায়
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  মোট আদায়
                </div>

              </div>



            </div>

            <div class="col-sm-5 col-md-5 col-xl-5">

              <div class="row">

                <div class="col-sm-2 col-md-2 col-xl-2">
                  সঞ্চয় ফেরত
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  বিবিধ খরচ
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  ভবন
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2" style="text-align: center;">
                  মৃত্যুকালীন অনুদান
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2" style="text-align: center;">
                  ঋণ প্রাদান
                </div>
                <div class="col-sm-2 col-md-2 col-xl-2">
                  মোট খরচ
                </div>

              </div>
              
            </div>

            

          </div><hr>


          <div style="text-align: center;font-size: 20px;height: 600px;overflow-y: auto;">

          
          <?php $__currentLoopData = $closing_info_instance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            

            <div class="row">


              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php if($single_info->month_info == "final_info"): ?>
                   
                   <?php echo e("৬ মাসের হিসাব"); ?>


                  <?php else: ?>

                    <?php echo e($single_info->month_info); ?>


                 <?php endif; ?>
              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($single_info->sonchoy_aday); ?>

              </div>

              <div class="col-sm-5 col-md-5 col-xl-5">

                <div class="row">

                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->munafa_aday); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->sheyar_aday); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->reserve_aday); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->vobon_theke_aday); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->rin_aday); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->mot_aday); ?>

                  </div>

                </div>



              </div>

              <div class="col-sm-5 col-md-5 col-xl-5">

                <div class="row">

                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->sonchoy_ferot); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->bibidh_khoroch); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->vobon); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2" style="text-align: center;">
                    <?php echo e($single_info->mrrittukalin_onudan); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2" style="text-align: center;">
                    <?php echo e($single_info->rin_prodan); ?>

                  </div>
                  <div class="col-sm-2 col-md-2 col-xl-2">
                    <?php echo e($single_info->mot_khoroch); ?>

                  </div>

                </div>
                
              </div>
              
              

            </div><hr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

      <?php endif; ?>

          




      
      
    
    
	        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jotbazar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>