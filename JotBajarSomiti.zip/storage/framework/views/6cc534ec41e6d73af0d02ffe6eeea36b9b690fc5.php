<?php $__env->startSection('hirizontal_nav_sodosso_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>



<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links">

		<div class="list-group">
		  <a href="<?php echo e(route('company_sodosso.home')); ?>" class="list-group-item active">সদস্য বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso_info_update_page')); ?>" class="list-group-item">সদস্য বিবরন হালনাগাদ </a>
		  <a href="<?php echo e(route('company.sodoss_sheyar_info')); ?>" class="list-group-item">শেয়ার বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso_sonchoy_info')); ?>" class="list-group-item">সঞ্চয় বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso__loan_info')); ?>" class="list-group-item">লোন বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso_delete')); ?>" class="list-group-item">সদস্য বাতিল </a>
		  <a href="<?php echo e(route('company_sodosso.masik_sonchoy_set')); ?>" class="list-group-item">মাসিক সঞ্চয় নির্ধারন </a>
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

	
	
	

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Form Design <small>different form elements</small></h2>
            
            <div class="clearfix"></div>
          </div>
        <div>
        <br />

        <form class="form-horizontal form-label-left">

        	<?php echo e(csrf_field()); ?>


              <div id="company_member_page_sovvo_sodosso_number" class="form-group">
                <label for="company_member_page_sovvo_sodosso_number_input" class="control-label col-md-3 col-sm-3 col-xs-12">
                	সভ্য সদস্য নম্বর
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input name="company_member_page_sovvo_sodosso_number_input" id="company_member_page_sovvo_sodosso_number_input" class="form-control col-md-7 col-xs-12"  type="number" required>
                </div>
              </div>


             


            
        </form>
      </div>
    </div>



    
    

    <div class="row container" style="margin-top: 20px; color: white;">
      <div id="user_info_main_frame" class="col-md-12 col-sm-12 col-xs-12" style="font-size: 22px;">
        
        <br>

        
        
        
        <div class="row">

          <div class="col-md-3 col-sm-3 col-xs-12">
            
          </div>
          

          <div id="member_image" class="col-md-3 col-sm-3 col-xs-12 thumbnail">

            

          </div>


        </div>


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            সভ্য সদস্য নম্বর 

          </div>
          
          <div id="member_no" class="col-md-6 col-sm-6 col-xs-12">
              
            

          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            নাম

          </div>
          
          <div id="member_name" class="col-md-6 col-sm-6 col-xs-12">
            
            

          </div>


        </div>
        



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            পিতার নাম

          </div>
          
          <div id="member_father_name" class="col-md-6 col-sm-6 col-xs-12">
            

          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
           মাতার নাম

          </div>
          
          <div id="member_mother_name" class="col-md-6 col-sm-6 col-xs-12">
            

          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            
            স্বামি / স্ত্রী এর নাম 

          </div>
          
          <div id="member_husbandORwife_name" class="col-md-6 col-sm-6 col-xs-12">
            

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            বর্তমান ঠিকানা

          </div>
          
          <div id="member_present_address" class="col-md-6 col-sm-6 col-xs-12">
            

          </div>


        </div>


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            স্থায়ী ঠিকানা

          </div>
          
          <div id="member_permanent_address" class="col-md-6 col-sm-6 col-xs-12">
            

          </div>


        </div>





        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            মোবাইল নম্বর 

          </div>
          
          <div id="member_mobile_no" class="col-md-6 col-sm-6 col-xs-12">
           

          </div>


        </div>


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            নোমিনির নাম

          </div>
          
          <div id="nominee_name_input" class="col-md-6 col-sm-6 col-xs-12">
           

          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            নোমিনির সাথে সম্পর্ক 

          </div>
          
          <div id="nominee_relation_input" class="col-md-6 col-sm-6 col-xs-12">
           

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            সদস্য হওয়ার তারিখ 

          </div>
          
          <div id="member_date_of_being_user" class="col-md-6 col-sm-6 col-xs-12">
            

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            একাউন্ট

          </div>
          
          <div id="member_account_status" class="col-md-6 col-sm-6 col-xs-12">
            
            

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            শেয়ার সংখা

          </div>
          
          <div id="member_sheyar" class="col-md-6 col-sm-6 col-xs-12">
                        
            
            
          
          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            ফিক্সড সঞ্চয় 

          </div>
          
          <div id="member_fixed_sonchoy" class="col-md-6 col-sm-6 col-xs-12">
                        
            
            
          
          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            মোট সঞ্চয়

          </div>
          
          <div id="member_net_sonchoy" class="col-md-6 col-sm-6 col-xs-12">
                        
            
            
          
          </div>


        </div>
        


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            মোট লোন 

          </div>
          
          <div id="member_net_loan" class="col-md-6 col-sm-6 col-xs-12">
                        
            
            
          
          </div>


        </div>
        <hr>


        

      </div>
    </div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jotbazar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>