<?php $__env->startSection('hirizontal_nav_sheyar_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>



<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links" style="font-size: 17px;">

		<div class="list-group">
		  <a href="<?php echo e(route('company.all_sheyar')); ?>" class="list-group-item active">সব শেয়ার বিবরন </a>
		  <a href="<?php echo e(route('company.kroy_sheyar')); ?>" class="list-group-item">ক্রয় </a>
		  <a href="<?php echo e(route('company.bikroy_sheyar')); ?>" class="list-group-item">হস্তান্তর </a>
		  
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

	<div class="table-responsive" style="margin-top: 20px;">
	  <table class="table table-hover table-striped">
	    
	  	<thead>
	  	      <tr>
	  	        <th style="text-align: center; font-size: 22px;">যে ক্রয় করেছে /<br> যে বিক্রয় করেছে </th>
	  	        <th style="text-align: center; font-size: 22px;">শেয়ার সংখা </th>
	  	        <th style="text-align: center; font-size: 22px;">টাকার পরিমান </th>
	  	        <th style="text-align: center; font-size: 22px;">যার কাছে বিক্রয় করা হয়েছে </th>
	  	        <th style="text-align: center; font-size: 22px;">তারিখ </th>
	  	      </tr>
	  	</thead>
	  	    <tbody style="text-align: center; font-size: 22px;">
	  	    	<?php $__currentLoopData = $sheyar_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_sheyar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	    		

		  	      <tr>
		  	        <td>
		  	        	
		  	        	<?php echo e($single_sheyar->UserBasicInfoKroy->name ." ( ". $single_sheyar->UserBasicInfoKroy->membership_no ." )"); ?>

		  	        	
		  	        </td>
		  	        <td><?php echo e($single_sheyar->sheyar_amount / 100); ?></td>
		  	        <td><?php echo e($single_sheyar->sheyar_amount); ?></td>
		  	        <td>
		  	        	<?php if($single_sheyar->to_whom != null): ?>
		  	        	<?php echo e($single_sheyar->UserBasicInfoBikroy->name ." ( ". $single_sheyar->UserBasicInfoBikroy->membership_no ." )"); ?>

		  	        	<?php endif; ?>
		  	        </td>
		  	        <td><?php echo e($single_sheyar->updated_at->formatLocalized('%A %d %B %Y')); ?></td>
		  	      </tr>
	  	    		
	  	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	      
	  	    </tbody>

	  </table>
	</div>

	<div class="pull-right" style="font-size: 20px;">

		<?php echo e($sheyar_info->links()); ?>

		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jotbazar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>