<!DOCTYPE html>
<html>
<head>

	<!--   meta data   -->
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--   heading   -->
	
	<title>জোতবাজার বণিক সমবায় সমিতি</title>

	

	<!--   external css group   -->
	
	
	<!-- Latest compiled and minified CSS -->
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> -->

	
	<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">

<!-- 002B36 -->

</head>
<body>

	


	<div id="heading_banner">

		<img id="bannar_image" src="<?php echo e(asset('photo/bannar.jpg')); ?>" alt="">

	</div>


	<nav id="navigation_bar" class="navbar navbar-inverse navbar-fixed-top" style="background-color: #002B36;margin-top: 150px;">
	      <div class="container">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
	            <span class="sr-only">Toggle navigation</span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
	          <!-- <a class="navbar-brand" href="#">Project name</a> -->
	        </div>
	        <div id="navbar" class="collapse navbar-collapse">
	          <ul class="nav navbar-nav">
	            <li <?php echo $__env->yieldContent('hirizontal_nav_dailyEntry_active'); ?>><a href="<?php echo e(route('daily_entry.home')); ?>">প্রাত্যহিক আদান-প্রদান</a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_sheyar_active'); ?>><a href="<?php echo e(route('company.all_sheyar')); ?>">শেয়ার </a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_sonchoy_active'); ?>><a href="<?php echo e(route('compnay.net_sonchoy')); ?>">সঞ্চয়</a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_loan_active'); ?>><a href="<?php echo e(route('company.loan_biboron')); ?>">লোন </a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_bibidh_active'); ?>><a href="<?php echo e(route('company.reserve_income')); ?>">রিজার্ভ</a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_closing_active'); ?>><a href="<?php echo e(route('company.upcoming_closing_info')); ?>">ক্লোজিং</a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_sodosso_active'); ?>><a href="<?php echo e(route('company_sodosso.home')); ?>">সদস্য</a></li>

	            <li <?php echo $__env->yieldContent('hirizontal_nav_report_active'); ?>><a href="<?php echo e(route('company.daily_report')); ?>">রিপোর্ট</a></li>

	            



	            <li>
	                <a href="<?php echo e(route('logout')); ?>"
	                    onclick="event.preventDefault();
	                             document.getElementById('logout-form').submit();">
	                    লগ আউট
	                </a>

	                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
	                    <?php echo e(csrf_field()); ?>

	                </form>
	            </li>




	            

	          </ul>
	        </div><!--/.nav-collapse -->
	      </div>
	    </nav>


	<!-- <div id="navigation_bar"> -->
		
	

	<!-- </div> -->


	<div id="main_body" style="margin-top: 50px;">
		
		<div class="col-sm-<?php echo $__env->yieldContent('sidebar_column_number'); ?>">


			<?php echo $__env->yieldContent('sidebar_navigation'); ?>


		</div>

		<div class="col-sm-<?php echo $__env->yieldContent('main_content_column_number'); ?>">
			
	        
			<?php echo $__env->yieldContent('main_frame_content'); ?>


		</div>

	</div>

	<div id="footer">
		
	</div>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

	
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>

	
	<script src="<?php echo e(asset('js/app.js')); ?>"></script>

    

    <!-- Latest compiled and minified JavaScript -->
    

    <script type="text/javascript" src="<?php echo e(asset('js/jQuery.print.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>


</body>
</html>