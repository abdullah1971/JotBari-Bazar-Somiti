<?php $__env->startSection('hirizontal_nav_sodosso_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>


<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links">

		<div class="list-group">
      <a href="<?php echo e(route('company_sodosso.home')); ?>" class="list-group-item">সদস্য বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso_info_update_page')); ?>" class="list-group-item">সদস্য বিবরন হালনাগাদ </a>
		  <a href="<?php echo e(route('company.sodoss_sheyar_info')); ?>" class="list-group-item">শেয়ার বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso_sonchoy_info')); ?>" class="list-group-item">সঞ্চয় বিবরন </a>
      <a href="<?php echo e(route('company.sodosso__loan_info')); ?>" class="list-group-item active">লোন বিবরন </a>
		  <a href="<?php echo e(route('company.sodosso_delete')); ?>" class="list-group-item">সদস্য বাতিল </a>
		  <a href="<?php echo e(route('company_sodosso.masik_sonchoy_set')); ?>" class="list-group-item">মাসিক সঞ্চয় নির্ধারন </a>
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Form Design <small>different form elements</small></h2>
            
            <div class="clearfix"></div>
          </div>
        <div>
        <br />

        <form id="" class="form-horizontal form-label-left" method="post" action="<?php echo e(route('company.single_sodosso__loan_info')); ?>">

        	<?php echo e(csrf_field()); ?>


              <div id="sovvo_sodosso_number" class="form-group">
                <label for="sovvo_sodosso_number_input" class="control-label col-md-3 col-sm-3 col-xs-12">
                	সভ্য সদস্য নম্বর
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input name="sovvo_sodosso_number_input" id="sovvo_sodosso_number_input" class="form-control col-md-7 col-xs-12"  type="number" required>
                </div>
              </div>


              


            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12">
              	
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                
              	<button type="submit" class="btn btn-success pull-right">Submit</button>

				  	

              </div>
            </div>
        </form>
      </div>
    </div>




    <!-- sheyar info -->

    <?php if(!$loan_info->isEmpty()): ?>
      
      <div class="table-responsive" style="margin-top: 20px;">
        <table class="table table-hover table-striped">
          
          <thead>
                <tr>
                  <th style="text-align: center; font-size: 22px;">সদস্য</th>
                  <th style="text-align: center; font-size: 22px;">লেন-দেনের ধরন</th>
                  <th style="text-align: center; font-size: 22px;">জরিমানা</th>
                  <th style="text-align: center; font-size: 22px;">মোট প্রদেয়</th>
                  
                  <th style="text-align: center; font-size: 22px;">তারিখ </th>
                </tr>
          </thead>
              <tbody style="text-align: center; font-size: 22px;">
                <?php $__currentLoopData = $loan_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  

                  <tr>
                    <td>
                      
                      <?php echo e($single_loan->UserBasicInfo->name ." ( ". $single_loan->UserBasicInfo->membership_no ." )"); ?>

                      
                    </td>
                    <td>
                      <?php if($single_loan->info_type == "loan_masik_munafa"): ?>
                        
                        <?php echo e("মাসিক লোনের মুনাফা"); ?>


                      <?php elseif($single_loan->info_type == "loan_bitoron"): ?>

                        <?php echo e("লোন গ্রহন"); ?>


                      <?php elseif($single_loan->info_type == "loan_joma"): ?>

                        <?php echo e("লোন শোধ"); ?>


                      
                      <?php endif; ?>
                    </td>
                    <td><?php echo e($single_loan->jorimana_amount); ?></td>
                    <td>
                      <?php if($single_loan->info_type == "loan_masik_munafa"): ?>
                        
                        <?php echo e($single_loan->total_amount); ?>


                      <?php else: ?>

                        <?php echo e($single_loan->money_amount); ?>

                      <?php endif; ?>
                    </td>

                    
                    <td><?php echo e($single_loan->updated_at->formatLocalized('%A %d %B %Y')); ?></td>
                  </tr>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </tbody>

        </table>
      </div>

      <div class="pull-right" style="font-size: 20px;">

        <?php echo e($loan_info->links()); ?>

        
      </div>
      
    <?php endif; ?>

    
	        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jotbazar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>