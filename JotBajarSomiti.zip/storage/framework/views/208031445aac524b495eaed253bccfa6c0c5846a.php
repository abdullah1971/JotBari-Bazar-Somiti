<?php $__env->startSection('hirizontal_nav_sodoss_biboron_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>


<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links" style="font-size: 17px;">

		<div class="list-group">

		  <a href="<?php echo e(route('user.info_details')); ?>" class="list-group-item active">সদস্য বিবরন </a>
		  
		  
		 
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

    <div class="row container" style="margin-top: 20px; color: white;">
      <div id="user_info_main_frame" class="col-md-12 col-sm-12 col-xs-12" style="font-size: 22px;">
        
        <br>

        
        
        
        <div class="row">

          <div class="col-md-3 col-sm-3 col-xs-12">
            
          </div>
          
          
          
          

          <div class="col-md-3 col-sm-3 col-xs-12 thumbnail">

            <?php if($info_status): ?>
              
             <img src=<?php echo e(asset("storage/images/$user_info_instance->image_path")); ?> alt="">
              
            <?php endif; ?>
          </div>


        </div>


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            সভ্য সদস্য নম্বর 

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
              
            <?php echo e($user->membership_no); ?>


          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            নাম

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            
            <?php echo e($user->name); ?>


          </div>


        </div>
        



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            পিতার নাম

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->user_father_name); ?>


            <?php endif; ?>

          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
           মাতার নাম

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->user_mother_name); ?>


            <?php endif; ?>

          </div>


        </div>



        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            
            স্বামি / স্ত্রী এর নাম 

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->user_husbandORwife_name); ?>


            <?php endif; ?>

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            বর্তমান ঠিকানা

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->present_address); ?>


            <?php endif; ?>

          </div>


        </div>


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            স্থায়ী ঠিকানা

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->permanent_address); ?>


            <?php endif; ?>

          </div>


        </div>





        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            মোবাইল নম্বর 

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->mobile_no); ?>


            <?php endif; ?>

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            সদস্য হওয়ার তারিখ 

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php if($info_status): ?>
              
              <?php echo e($user_info_instance->date_of_being_user); ?>


            <?php endif; ?>

          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            একাউন্ট

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
            
            <?php echo e($user_account_instance->account_status); ?>


          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            শেয়ার সংখা

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
                        
            <?php echo e($user_account_instance->sheyar); ?>

            
          
          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            ফিক্সড সঞ্চয় 

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
                        
            <?php echo e($user_account_instance->fixed_sonchoy); ?> tk
            
          
          </div>


        </div>




        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            মোট সঞ্চয়

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
                        
            <?php echo e($user_account_instance->net_sonchoy); ?> tk
            
          
          </div>


        </div>
        


        
        
        <hr>
        <div class="row">

          <div class="col-md-2 col-sm-2 col-xs-12">
            
          </div>
          
          <div class="col-md-3 col-sm-3 col-xs-12">
            
            মোট লোন 

          </div>
          
          <div class="col-md-6 col-sm-6 col-xs-12">
                        
            <?php echo e($user_account_instance->taken_loan_amount - $user_account_instance->paid_loan_amount); ?> tk
            
          
          </div>


        </div>
        <hr>


        

      </div>
    </div>
	        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>