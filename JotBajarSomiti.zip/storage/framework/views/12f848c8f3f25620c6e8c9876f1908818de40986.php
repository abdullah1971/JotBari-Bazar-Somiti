<?php $__env->startSection('hirizontal_nav_report_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>


<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links">

		<div class="list-group">

      <a href="<?php echo e(route('company.daily_report')); ?>" class="list-group-item">ডেইলি রিপোর্ট</a>
      <a href="<?php echo e(route('company.monthly_report')); ?>" class="list-group-item active">মাসিক রিপোর্ট</a>
      <a href="<?php echo e(route('company.closing_report')); ?>" class="list-group-item">ক্লোজিং রিপোর্ট </a>
		  
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Form Design <small>different form elements</small></h2>
            
            <div class="clearfix"></div>
          </div>
        <div>
        <br />

        <form id="" class="form-horizontal form-label-left" method="post" action="<?php echo e(route('company.monthly_report_info')); ?>">

        	<?php echo e(csrf_field()); ?>



              <div class="row">
                
                <div class="col-sm-5 col-md-5 col-xl-6">
                  
                  <div id="month_for_monthly_report" class="form-group">
                    <label for="month_for_monthly_report_input" class="control-label col-md-3 col-sm-3 col-xs-12">
                      মাস 
                    </label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                      

                      <select id='month' name="month"  class="form-control col-md-7 col-xs-12">
                          <option value=''>--Select Month--</option>
                          <option style="font-size: 20px;" value='01'>Janaury</option>
                          <option style="font-size: 20px;" value='02'>February</option>
                          <option style="font-size: 20px;" value='03'>March</option>
                          <option style="font-size: 20px;" value='04'>April</option>
                          <option style="font-size: 20px;" value='05'>May</option>
                          <option style="font-size: 20px;" value='06'>June</option>
                          <option style="font-size: 20px;" value='07'>July</option>
                          <option style="font-size: 20px;" value='08'>August</option>
                          <option style="font-size: 20px;" value='09'>September</option>
                          <option style="font-size: 20px;" value='10'>October</option>
                          <option style="font-size: 20px;" value='11'>November</option>
                          <option style="font-size: 20px;" value='12'>December</option>
                          </select> 

                    </div>
                  </div>

                </div>

                <div class="col-sm-5 col-md-5 col-xl-6">
                  
                  <div id="year_for_monthly_report" class="form-group">
                    <label for="year_for_monthly_report_input" class="control-label col-md-3 col-sm-3 col-xs-12">
                      বছর 
                    </label>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                      

                      <?php
                        
                        $start_year = 1980;

                        $end_year = Carbon\Carbon::now()->year;

                      ?>

                      <select id='year' name="year"  class="form-control col-md-7 col-xs-12">
                          <option value=''>--Select Year--</option>
                          <?php for($i = $end_year; $i >= $start_year; $i--): ?>
                            
                            <option style="font-size: 20px;" value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            
                          <?php endfor; ?>
                          
                          </select> 

                    </div>
                  </div>

                </div>




                <div class="col-sm-2 col-md-2 col-xl-2">
                  

                  <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12">
                      
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      
                      <button type="submit" class="btn btn-success pull-right">Submit</button>

                  

                    </div>
                  </div>

                </div>

              </div>

              

              


              


            
        </form>
      </div>
    </div>




    <!-- masik report info -->


      <?php if($time != null): ?>

        <div id="masik_report">
          
        
        

          <div class="row" style="position: ;background-color: #27ae60; color: white;font-size: 21px;">
            
            <div class="col-sm-1 col-md-1 col-xl-1">
              তারিখ
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              সঞ্চয় আদায়
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              মুনাফা আদায়
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              শেয়ার আদায়
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              বিবিধ আদায়
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              ভবন আয়
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              ঋণ আদায় 
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              মোট আয় 
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              সঞ্চয় উত্তোলন 
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              বিবিধ ব্যয় 
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              ঋণ প্রদান 
            </div>
            <div class="col-sm-1 col-md-1 col-xl-1">
              মোট ব্যয়  
            </div>

          </div><hr>


          <div style="height: 600px;overflow-y: auto; text-align: center;font-size: 20px;">

          
          <?php for($i = 0; $i < $end_date; $i++): ?>


            <?php
              $j = $i + 1;
            ?>



            
            <div class="row">
              
              <div class="col-sm-1 col-md-1 col-xl-1">
                 <?php if($i>8): ?>
                   <?php echo e($date = $time."-$j"); ?>

                 <?php else: ?>
                   <?php echo e($date = $time."-0$j"); ?>

                 <?php endif; ?>
              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($sonchoy_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($munafa_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($sheyar_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($reserve_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($vobon_theke_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($rin_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($mot_aday[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($sonchoy_uttolon[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($reserve_bay[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($rin_prodan[$i]); ?>

              </div>
              <div class="col-sm-1 col-md-1 col-xl-1">
                <?php echo e($mot_bay[$i]); ?>

              </div>

            </div><hr>

          <?php endfor; ?>
        </div>

      </div>

      <?php endif; ?>

          
      <div class="pull-left" style="font-size: 20px;">

        <button type="" id="masik_report_print_button" class="btn btn-success">প্রিন্ট করুন </button>
        
      </div>



      
      

          
          
               

     
      
    
    
	        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jotbazar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>