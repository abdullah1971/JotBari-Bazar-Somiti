<?php $__env->startSection('hirizontal_nav_loan_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>



<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links" style="font-size: 17px;">

		<div class="list-group">
		  <a href="<?php echo e(route('user.loan_uttolon')); ?>" class="list-group-item">লোন উত্তোলন</a>
		  <a href="<?php echo e(route('user.loan_joma')); ?>" class="list-group-item active">লোন জমা</a>
		  <a href="<?php echo e(route('user.loan_masik_munafa')); ?>" class="list-group-item">লোনের মাসিক মুনাফা</a>
		  
		  
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

	<div class="table-responsive" style="margin-top: 20px;">
	  <table class="table table-hover table-striped">
	    
	  	<thead>
	  	      <tr>
	  	        <th style="text-align: center; font-size: 22px;">লোন শোধের পরিমান </th>
	  	        
	  	        <th style="text-align: center; font-size: 22px;">তারিখ </th>
	  	      </tr>
	  	</thead>
	  	    <tbody style="text-align: center; font-size: 22px;">

	  	    	<?php $__currentLoopData = $loan_instance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	    		

		  	      <tr>
		  	        <td><?php echo e($single_loan->money_amount); ?></td>
		  	        
		  	        <td><?php echo e($single_loan->updated_at->formatLocalized('%A %d %B %Y')); ?></td>	  	        
		  	      </tr>
	  	    		
	  	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	      
	  	    </tbody>

	  </table>
	</div>

	<div class="pull-right" style="font-size: 20px;">

		<?php echo e($loan_instance->links()); ?>

		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>