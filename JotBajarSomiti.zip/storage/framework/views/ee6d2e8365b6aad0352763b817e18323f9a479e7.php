<?php $__env->startSection('hirizontal_nav_bibidh_active', 'class=active'); ?>



<?php $__env->startSection('sidebar_column_number', '2'); ?>
<?php $__env->startSection('main_content_column_number', '10'); ?>



<?php $__env->startSection('sidebar_navigation'); ?>

	<div id="sidebar_links" style="font-size: 17px;">

		<div class="list-group">
			
		  <a href="<?php echo e(route('company.reserve_income')); ?>" class="list-group-item active">আয় </a>
		  <a href="<?php echo e(route('company.reserve_spend')); ?>" class="list-group-item">ব্যয় </a>
		  
		  
		</div>

	</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_frame_content'); ?>

	<div class="table-responsive" style="margin-top: 20px;">
	  <table class="table table-hover table-striped">
	    
	  	<thead>
	  	      <tr>
	  	        <th style="text-align: center; font-size: 22px;">উৎস </th>
	  	        <th style="text-align: center; font-size: 22px;">সদস্য বিবরন ( জরিমানা ) </th>
	  	        <th style="text-align: center; font-size: 22px;">টাকার পরিমান</th>
	  	        <th style="text-align: center; font-size: 22px;">তারিখ </th>
	  	      </tr>
	  	</thead>
	  	    <tbody style="text-align: center; font-size: 22px;">

	  	    	<?php $__currentLoopData = $reserve_instance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_reserve_income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	    		

		  	      <tr>
		  	        <td>
		  	        	<?php if($single_reserve_income->info_type == "income"): ?>
		  	        		
		  	        		<?php echo e($single_reserve_income->subject); ?>


		  	        	<?php elseif($single_reserve_income->info_type == "sonchoy_masik_jorimana"): ?>

		  	        		<?php echo e("সঞ্চয়ের জরিমানা"); ?>


	  	        		<?php elseif($single_reserve_income->info_type == "loan_masik_jorimana"): ?>

	  	        			<?php echo e("লোনের মুনাফার জরিমানা "); ?>

	  	        		
		  	        	<?php endif; ?>


		  	        </td>
		  	        <td>
		  	        	<?php if($single_reserve_income->info_type == "sonchoy_masik_jorimana" || $single_reserve_income->info_type == "loan_masik_jorimana"): ?>
		  	        		

		  	        		<?php echo e($single_reserve_income->UserBasicInfo->name ." ( ". $single_reserve_income->UserBasicInfo->membership_no . " ) "); ?>


		  	        		
		  	        		
		  	        	<?php endif; ?>
		  	        </td>
		  	        <td><?php echo e($single_reserve_income->money_amount); ?></td>
		  	        <td><?php echo e($single_reserve_income->updated_at->formatLocalized('%A %d %B %Y')); ?></td>
		  	        	  	        
		  	      </tr>
	  	    		
	  	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	      
	  	    </tbody>

	  </table>
	</div>

	<div class="pull-right" style="font-size: 20px;">

		<?php echo e($reserve_instance->links()); ?>

		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.jotbazar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>